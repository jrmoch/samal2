const approvedBody = document.getElementById("approvedBody");
const pendingBody = document.getElementById("pendingBody");
const completedBody = document.getElementById("completedBody");

async function loadAppointments() {
  approvedBody.innerHTML = "";
  pendingBody.innerHTML = "";
  completedBody.innerHTML = "";

  try {
    const res = await fetch("http://localhost:5000/api/appointments");
    const appointments = await res.json();

    appointments.forEach(appt => {
      const row = document.createElement("tr");

      const baseColumns = `
        <td>SIC-${String(appt.id).padStart(4, "0")}</td>
        <td>${appt.name}</td>
        <td>${appt.phone}</td>
        <td>${appt.email}</td>
        <td>${appt.date}</td>
        <td>${appt.time}</td>
        <td>${appt.service}</td>
        <td><span class="status ${appt.status.toLowerCase()}">${appt.status}</span></td>
      `;

      if (appt.status === "Approved") {
        row.innerHTML = baseColumns + `
          <td><button class="complete-btn" data-id="${appt.id}">Completed</button></td>
        `;
        approvedBody.appendChild(row);
      } else if (appt.status === "Rescheduled") {
        row.innerHTML = baseColumns + `
          <td><button class="approve-btn" data-id="${appt.id}">Approve</button></td>
        `;
        pendingBody.appendChild(row);
      } else if (appt.status === "Completed") {
        row.innerHTML = baseColumns; // No action column
        completedBody.appendChild(row);
      }
    });

    // Attach button listeners
    document.querySelectorAll(".approve-btn").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.getAttribute("data-id");
        await updateStatus(id, "Approved");
      });
    });

    document.querySelectorAll(".complete-btn").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.getAttribute("data-id");
        await updateStatus(id, "Completed");
      });
    });

  } catch (err) {
    console.error("Error loading appointments:", err);
  }
}

async function updateStatus(id, newStatus) {
  try {
    const res = await fetch(`http://localhost:5000/api/appointments/${id}/status`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus })
    });
    if (res.ok) {
      loadAppointments(); // refresh table
    }
  } catch (err) {
    console.error("Error updating status:", err);
  }
}

loadAppointments();
setInterval(loadAppointments, 10000); // auto-refresh every 10s
